package com.example.data

object UserRepository {
    fun getUsers(): List<User> = listOf(
        User(
            id = "1",
            name = "أحمد محمد",
            email = "ahmed@gmail.com",
            isOnline = true,
            lastMessage = "مرحبا، كيف حالك؟",
            unreadCount = 2
        ),
        User(
            id = "2",
            name = "Sara Ali",
            email = "sara.ali@gmail.com",
            isOnline = false,
            lastSeen = "10:30 AM",
            lastMessage = "See you tomorrow!",
            unreadCount = 0
        ),
        User(
            id = "3",
            name = "Carlos Rivera",
            email = "carlos@gmail.com",
            isOnline = true,
            lastMessage = "¿Cómo estás?",
            unreadCount = 1
        ),
        User(
            id = "4",
            name = "Marie Dubois",
            email = "marie@gmail.com",
            isOnline = false,
            lastSeen = "Yesterday",
            lastMessage = "À bientôt !",
            unreadCount = 0
        ),
        User(
            id = "5",
            name = "Yuki Tanaka",
            email = "yuki@gmail.com",
            isOnline = true,
            lastMessage = "こんにちは！",
            unreadCount = 3
        ),
        User(
            id = "6",
            name = "Hans Müller",
            email = "hans@gmail.com",
            isOnline = false,
            lastSeen = "2 hours ago",
            lastMessage = "Guten Tag!",
            unreadCount = 0
        ),
        User(
            id = "7",
            name = "Priya Sharma",
            email = "priya@gmail.com",
            isOnline = true,
            lastMessage = "नमस्ते, कैसे हो?",
            unreadCount = 0
        ),
        User(
            id = "8",
            name = "Li Wei",
            email = "liwei@gmail.com",
            isOnline = false,
            lastSeen = "Monday",
            lastMessage = "你好！",
            unreadCount = 5
        )
    )
}
