# ALHWARY

Modern messaging app with multi-language support and AI features.

## Supported Languages

The app currently includes translations for:

- English (default)
- Arabic (العربية)
- Spanish (Español)
- French (Français)
- German (Deutsch)
- Portuguese (Português)
- Russian (Русский)
- Turkish (Türkçe)
- Indonesian (Bahasa Indonesia)
- Hindi (हिन्दी)
- Chinese Simplified (简体中文)
- Japanese (日本語)
- Korean (한국어)
- Italian (Italiano)
- Dutch (Nederlands)

The app automatically uses the device language if available, otherwise falls back to English.

## Run Locally

**Prerequisites:** [Android Studio](https://developer.android.com/studio)

1. Open Android Studio
2. Select **Open** and choose this project directory
3. Allow Android Studio to fix any incompatibilities
4. Create a `.env` file and set `GEMINI_API_KEY` (see `.env.example`)
5. Run the app on an emulator or physical device
